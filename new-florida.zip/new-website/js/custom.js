// includes Script

gsap.registerPlugin(MotionPathPlugin);

$(document).scroll(function () {
  if ($(window).scrollTop() > 100) {
    $("header.header").addClass("navfixed");
  } else {
    $("header.header").removeClass("navfixed");
  }
});

$(window).resize(() => {
  location.reload();
});

$(function () {
  $("#header").load("header.html");
  $("#footer").load("footer.html");

  $('#content').imagesLoaded().progress(function (instance, image) {
    var result = image.isLoaded ? 'loaded' : 'broken';
  }).done(function (instance) {

    window.scrollTo({ top: 0, behavior: 'instant' });


    $('.loader').fadeOut('1000');
    let mainTimeline = new TimelineMax();

    // ---------------------- Header Animation ----------------------  
    mainTimeline.fromTo(".navbar-nav", { opacity: 0, x: 500 }, {
      opacity: 1,
      duration: 0.5,
      x: 0,
    });

    // ---------------------- Hero Section Animation ----------------------  
    mainTimeline.fromTo(".main-box-1", { opacity: 0, x: 500, y: 500, scale: 0.4 }, {
      opacity: 1,
      duration: 0.7,
      x: 0,
      y: 0,
      scale: 1
    });

    mainTimeline.fromTo(".main-box-2", { opacity: 0, x: 200, y: 200 }, { opacity: 1, duration: 0.6, x: 0, y: 0 })

    mainTimeline.fromTo(".hero-pattern", { opacity: 0, x: 100, y: 100 }, { opacity: 1, duration: 0.8, x: 0, y: 0 })

    gsap.to("#Path_359", {
      duration: 0.7,
      repeat: 0,
      yoyo: false,
      ease: "none",
      motionPath: {
        path: ".st0",
        align: ".st0",
        alignOrigin: [0.5, 0.5]
      },
      scrollTrigger: {
        trigger: ".herosec",
        start: "top top",
        end: "bottom top",
        scrub: 0.1
      },
    });

    // ---------------------- About Section Animation ----------------------  
    mainTimeline.fromTo('.structure .anim-text', {
      opacity: 0,
      y: 50
    }, {
      opacity: 1,
      y: 0,
      stagger: 0.5,
      scrollTrigger: {
        trigger: ".structure",
        start: "top 50%",
        end: "40% 50%",
        scrub: 1.5
      }
    })

    var allBannerparent = document.querySelectorAll(".hex_totltip");

    let tootipBanner_arrays = [];
    let tootipItem_arrays = [];

    allBannerparent.forEach((item, index) => {
      tooltipBannerBox(item, tootipBanner_arrays, tootipItem_arrays);
    })

    if ($(window).width() >= 992) {
      leftandright(mainTimeline);
    }

    if ($(window).width() <= 991) {
      mobileleftri();
    }

    mainTimeline.fromTo('.about .anim-text', {
      opacity: 0,
      x: -150
    }, {
      opacity: 1,
      duration: 1,
      x: 0,
      stagger: 0.5,
      scrollTrigger: {
        trigger: ".about",
        start: "top 70%",
        end: "40% 50%",
        scrub: 1.5,
        // markers: true
      }
    })

    let constructon = document.querySelectorAll(".construct_li");
    let tootip_arrays = [];
    constructon.forEach((item, index) => {
      let crettootlobj = tooltipBox(item, item.querySelector('.desc_cutooltip'), tootip_arrays);
      tootip_arrays.push(crettootlobj);
    });



    $('a.navbar-brand').on('click', function () {
      window.scrollTo({
        top: 0,
        behavior: 'instant'
      });
    });

    $('.card.serc-card .plus_crit').on('click', function () {
      $('#portfolioModal').modal('show')
    });

    var project_el = $('#projects').offset()?.top;
    var construction_el = $('#construction').offset()?.top;
    var about_el = $('#about').offset()?.top;
    var contact_el = $('#contact').offset()?.top;

    var minusWidth = $('#projects').closest('.pin-spacer').css('height')?.replace('px', '');

    $(window).on('scroll', function () {

      $('#navbarSupportedContent .nav-link').removeClass('active');

      activeNavBar('#projects', project_el, parseInt(minusWidth));
      activeNavBar('#construction', construction_el, 0);
      activeNavBar('#about', about_el, 0);
      activeNavBar('#contact', contact_el, 0);

    });




    // ---------------------- Project Section Animation ----------------------  

    gsap.fromTo('.project_list_box .serc-card', {
      opacity: 0,
      y: 100,
    }, {
      opacity: 1,
      y: 0,
      stagger: 0.5,
      scrollTrigger: {
        trigger: ".projects_row",
        start: "top 90%",
        end: "bottom bottom",
        scrub: 3,
      }
    });


    var oldPageForm = localStorage.getItem('pageFrom'), redirectSection = localStorage.getItem('redirectSection');

    if (oldPageForm != 'index.html') {
  
      window.scrollTo({
        top: $(`${redirectSection}`).offset()?.top,
        behavior: 'instant'
      });

      gsap.fromTo($(this).attr("data-href"), {
        opacity: 0,
      }, {
        opacity: 1,
        duration: 0.3,
      });
    }



    $('.navbar-nav').on('click', '.nav-link', function () {

      var pathname = window.location.pathname.split('/').reverse()[0];

      $('.navbar-nav .nav-link').removeClass('active');

      localStorage.setItem("pageFrom", pathname);
      localStorage.setItem("redirectSection", $(this).attr("data-href"));

      $(this).addClass('active');

      if (pathname == 'index.html') {

        console.log($(`${$(this).attr("data-href")}`).offset().top)

        window.scrollTo({
          top: $(`${$(this).attr("data-href")}`).offset().top,
          behavior: 'instant'
        });

        gsap.fromTo($(this).attr("data-href"), {
          opacity: 0,
        }, {
          opacity: 1,
          duration: 0.3,
        });

      } else {
        window.location.href = 'index.html';
      }
    });

  });
});

const activeNavBar = (selector, position, min) => {

  var y_scroll_pos = window.pageYOffset;
  var scroll_top_el = position - 200;
  var scroll_bot_el = position + $(selector).height() + 100;

  if (selector === '#projects') {
    scroll_bot_el += min;
    scroll_bot_el -= $(selector).height();
    scroll_bot_el -= $(selector).height();
  }

  if (scroll_top_el <= y_scroll_pos && y_scroll_pos <= scroll_bot_el) {
    $('#navbarSupportedContent .nav-link').removeClass('active');
    $(`.nav-link[data-href="${selector}"]`).addClass('active');
  }
}

const tooltipBannerBox = (item, tootipBanner_arrays, tootipItem_arrays) => {

  var tween = TweenLite.from(item.querySelector(".desc_cutooltip"), 0.6, { y: 20, height: 0, autoAlpha: 0, paused: true, ease: "back.out(2)" });
  tween.reverse();

  // var banner = item.querySelector(".hexplus");
  var banner = item;

  banner.onclick = function (e) {
    tootipBanner_arrays.forEach((i, index) => {
      if (i !== tween) {
        i.reversed(true);
      }
    });
    tootipItem_arrays.forEach((vol, index) => {
      $(vol.querySelector('.fa-minus')).hide();
      $(vol.querySelector('.fa-plus')).show();
    });

    tween.reversed(!tween.reversed());


    if ($(item.querySelector(".desc_cutooltip")).css('opacity') == 0) {
      $(item.querySelector('.fa-plus')).hide();
      $(item.querySelector('.fa-minus')).show();
    } else {
      $(item.querySelector('.fa-minus')).hide();
      $(item.querySelector('.fa-plus')).show();
    }
  }

  $(document).click(function (e) {
    e.stopPropagation();

    //check if the clicked area is dropDown or not
    if ($(item).has(e.target).length === 0) {
      $(item.querySelector('.fa-minus')).hide();
      $(item.querySelector('.fa-plus')).show();
      tween.reversed(true);
    }
  });

  tootipBanner_arrays.push(tween);
  tootipItem_arrays.push(item);

}

const tooltipBox = (button, tooltipBox, arrays) => {
  var tool_banner = button;

  var tool_tween = TweenLite.from(tooltipBox, 0.6, { y: 20, scale: 0.5, autoAlpha: 0, paused: true, ease: "back.out(2)" });
  tool_tween.reverse();

  tool_banner.onclick = function () {
    arrays.forEach((item, index) => {
      item.reversed(true);
    });
    tool_tween.reversed(!tool_tween.reversed());
  }

  $(document).click(function (e) {
    e.stopPropagation();
    var container = $(".construction_bo");

    //check if the clicked area is dropDown or not
    if (container.has(e.target).length === 0) {
      tool_tween.reversed(true);
    }
  });


  return tool_tween;
}

const leftandright = (mainTimeline) => {

  // ---------------------- Project section animation -------------------------
  let carosola_anim = gsap.timeline({});

  carosola_anim.to(".right-scroll", {
    opacity: 1,
  });

  mainTimeline.add(carosola_anim);

  let right_sections = gsap.utils.toArray(".right-scroll .item");
  let right_scrollTween = mainTimeline.to(right_sections, {
    xPercent: -100 * (right_sections.length - 1),
    ease: "none",
    scrollTrigger: {
      trigger: ".projects",
      pin: true,
      scrub: 3,
      end: "+=6000"
    }
  });

  // ---------------------- leadership section animation -------------------------
  let left_sections = gsap.utils.toArray(".left-scroll .item");
  let left_scrollTimeline = gsap.timeline({
    scrollTrigger: {
      trigger: ".leadership",
      pin: true,
      // start: "top 20%",  
      pinSpacing: true,
      // markers: true,
      scrub: 3,
      end: "+=1000"
    }
  });

  let left_scrollTween = left_scrollTimeline.to(left_sections, {
    xPercent: 80 * (left_sections.length - 1),
    ease: "none", // <-- IMPORTANT!
  });

  mainTimeline.fromTo(".about .about-im",
    {
      opacity: 0, x: -500
    },
    {
      opacity: 1,
      x: 0,
      duration: 1,
      scrollTrigger: {
        trigger: ".about",
        start: "top 70%",
        end: "40% 50%",
        // markers: true,
        scrub: 1.5
      }
    }
  );

  mainTimeline.fromTo(".structure .imaged",
    {
      opacity: 0, x: -500
    },
    {
      opacity: 1,
      x: 0,
      duration: 1,
      scrollTrigger: {
        trigger: ".structure",
        start: "top 70%",
        end: "40% 50%",
        // markers: true,
        scrub: 1.5
      }
    }
  );

  // ---------------------- Contact section animation -------------------------
  let contact_timeline = gsap.timeline({});
  contact_timeline.to("#contact_dot", {
    duration: 0.7,
    // repeat: 12,
    yoyo: false,
    ease: "none",
    motionPath: {
      path: "#contact_path",
      align: "#contact_path",
      alignOrigin: [0.5, 0.5]
    },
    scrollTrigger: {
      trigger: ".contact_box",
      start: "top 50%",
      end: "60% 70%",
      scrub: 0.1
    },
  });

  contact_timeline.fromTo(".contact_box .imaged",
    {
      opacity: 0, x: -500
    },
    {
      opacity: 1,
      x: 0,
      duration: 1,
      scrollTrigger: {
        trigger: ".contact_box",
        start: "-20% 80%",
        end: "40% 70%",
        // markers: true,
        scrub: 1.5
      }
    }
  );

  contact_timeline.fromTo('.contact_box .anim-text', {
    opacity: 0,
    y: 50
  }, {
    opacity: 1,
    y: 0,
    stagger: 0.5,
    scrollTrigger: {
      trigger: ".contact_box",
      start: "top 50%",
      end: "40% 50%",
      scrub: 1.5
    }
  });

  mainTimeline.add(contact_timeline);
}

const mobileleftri = () => {
  $('.right-scrollcarousel, .left-scrollcarousel').owlCarousel({
    loop: false,
    margin: 20,
    nav: false,
    dots: false,
    autoWidth: true
  })
}