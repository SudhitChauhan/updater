
gsap.registerPlugin(MotionPathPlugin, ScrollTrigger, Observer);

let liveTime = gsap.timeline();


let right_sections = gsap.utils.toArray(".right-scroll .item");
let right_scrollTween = liveTime.to(right_sections, {
    xPercent: -120 * (right_sections.length - 1),
    ease: "none",
    scrollTrigger: {
        trigger: ".projects",
        pin: true,
        scrub: 1,
        end: "+=3000"
    }
});

let scroll_boxs = gsap.utils.toArray(".services .demo-bos");
let scrollsection = gsap.utils.selector(".serives-50");

liveTime.to('.serives-50 .right', {})

let service_scroll = liveTime.to(scroll_boxs, {
    yPercent: -100 * (scroll_boxs.length - 1),
    top:"100%",
    ease: "none",
    scrollTrigger: {
        trigger: ".services",
        pin: true,
        scrub: 1,
        end: "+=3000"
    }
});


let left_sections = gsap.utils.toArray(".left-scroll .item");
let left_scrollTween = liveTime.to(left_sections, {
    xPercent: 120 * (left_sections.length - 1),
    ease: "none", // <-- IMPORTANT!
    scrollTrigger: {
        trigger: ".leadership",
        pin: true,
        // markers: true,
        start: "top 20%",
        // // end: "bottom top",
        pinSpacing: true,
        scrub: 1,
        //snap: directionalSnap(1 / (sections.length - 1)),
        end: "+=3000"
    }
});
